package com.example.voice;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class STT {
    public static Context getApplicationContext() {
        return null;
    }

    public void startActivity(Intent mainActivityIntent) {

    }

    public void sttToActivity(String fName) {
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                OkHttpClient client = new OkHttpClient().newBuilder().build();
                MediaType mediaType= MediaType.parse("text/plain");
                RequestBody body = new MultipartBody.Builder().setType(MultipartBody.FORM)
                        .addFormDataPart("file", "BankUserSpeech.3gp", RequestBody.create((new File(fName)), MediaType.parse("application/octet-stream")))
                        .addFormDataPart("vtt", "true")
                        .addFormDataPart("language", "english")
                        .build();
                Request request = new Request.Builder()
                        .url("https://asr.iitm.ac.in/asr/v2/decode")
                        .method("POST", body)
                        .build();
                String textFromSpeech = " ";
                try {
                    Response response = client.newCall(request).execute();
                    String jsonData = response.body().string();
                    Log.e("Response", jsonData);
                    JSONObject jObj = new JSONObject(jsonData);
                    textFromSpeech = jObj.getString("transcript");
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                if (textFromSpeech.toLowerCase().contains("back")) {
                    Intent mainActivityIntent = new Intent (getApplicationContext(), MainActivity.class);
                    startActivity((mainActivityIntent));
                }
            }
        });
        thread.start();
    }

}
