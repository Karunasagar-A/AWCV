package com.example.voice;

import android.media.MediaPlayer;

import java.io.IOException;

public class PlayAudio {

        public MediaPlayer mediaPlayer;

        public void playAudio(String fileName) {
            mediaPlayer = new MediaPlayer();
            try {
                mediaPlayer.setDataSource(fileName);
                mediaPlayer.prepare();
                mediaPlayer.start();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

}
