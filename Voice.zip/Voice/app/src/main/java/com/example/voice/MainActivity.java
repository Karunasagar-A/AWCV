package com.example.voice;

import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;


public class MainActivity extends AppCompatActivity {
    public TextView recordingStatus;
    public ImageButton recordButton = null;
    public MediaRecorder recorder;
    public  STT stt;
    public  PlayAudio play;
    private TTSClass tts;
    private String fileName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        stt = new STT();
        tts = new TTSClass();
        recordingStatus = findViewById(R.id.recordingStatus);
        recordButton = findViewById(R.id.recB);
        recordButton.setImageResource(R.drawable.recordicon2);
        recorder = new MediaRecorder();
        play = new PlayAudio();

        recordButton.setOnTouchListener(new View.OnTouchListener() {


            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        startRecording();
                        recordingStatus.setText("Recording has started");
                        recordButton.setImageResource(R.drawable.recordicon3);
                        recordButton.setScaleX(1.5f);
                        recordButton.setScaleY(1.5f);
                        break;

                    case MotionEvent.ACTION_MOVE:
                        // touch move code
//
                        break;

                    case MotionEvent.ACTION_UP:
                        stopRecording();
                        recordingStatus.setText("Recording has stop");
                        recordButton.setImageResource(R.drawable.recordicon2);
                        recordButton.setScaleX(1);
                        recordButton.setScaleY(1);
                        PlayAudio pA = new PlayAudio();
                        pA.playAudio(fileName);
                        stt.sttToActivity(fileName);

                        break;
                }
                return true;
            }
        });
    }

    ;

    public void startRecording() {
        try {
            // Set up the MediaRecorder
            Log.e("Reached here","hey");
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(getOutputFilePath());
            recorder.start();

            //Log.d("Recording", "Recording started");
            Toast.makeText(MainActivity.this, "Recording started", Toast.LENGTH_SHORT).show();// Add this log statement
            // Prepare and start the recording0

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String getOutputFilePath() {

        File directory = new File(Environment.getExternalStorageDirectory(), "AudioFiles");
        if (!directory.exists()) {
            directory.mkdirs();
        }


        fileName = "audio_" + System.currentTimeMillis() + ".3gp";

        // Create the file path by combining the directory path and file name
        String filePath = directory.getAbsolutePath() + File.separator + fileName;
        Log.e("Storage:", filePath);

        return filePath;
    }

    private void stopRecording() {
        try {

            recorder.stop();
            recorder.release();
            recorder = null;
        } catch (IllegalStateException e) {
            e.printStackTrace();
        }
    }


}

